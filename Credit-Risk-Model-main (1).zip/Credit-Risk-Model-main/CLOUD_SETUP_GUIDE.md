# Google Cloud Setup Guide for Windows

## Install Google Cloud CLI
1. Download from: https://cloud.google.com/sdk/docs/install-windows
2. Run the installer (GoogleCloudSDKInstaller.exe)
3. Follow installation wizard
4. Choose "Add gcloud to PATH"

## Install Terraform
1. Download from: https://www.terraform.io/downloads
2. Extract terraform.exe to a folder (e.g., C:\terraform)
3. Add to PATH: System Properties > Environment Variables > PATH > Add C:\terraform

## Install Docker Desktop
1. Download from: https://www.docker.com/products/docker-desktop
2. Install Docker Desktop
3. Enable WSL 2 integration if prompted
4. Restart computer

## Verify Installations
Run these commands in PowerShell:
```powershell
gcloud --version
terraform --version
docker --version
```
