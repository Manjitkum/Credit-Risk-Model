#!/usr/bin/env python3
"""
Cloud-Native Setup Diagnostic Tool
This script checks if your cloud-native credit risk platform is properly configured
"""

import os
import sys
import subprocess
import json
from pathlib import Path

def print_header(title):
    print(f"\n{'='*60}")
    print(f"🔍 {title}")
    print(f"{'='*60}")

def print_status(status, message):
    symbols = {"✅": "PASS", "❌": "FAIL", "⚠️": "WARNING", "ℹ️": "INFO"}
    print(f"{status} {message}")

def check_python_dependencies():
    print_header("Python Dependencies Check")
    
    required_packages = [
        "streamlit",
        "pandas", 
        "numpy",
        "plotly",
        "google.cloud.aiplatform",
        "google.cloud.bigquery", 
        "google.cloud.storage",
        "sklearn",
        "xgboost",
        "joblib"
    ]
    
    for package in required_packages:
        try:
            __import__(package)
            print_status("✅", f"{package} - Installed")
        except ImportError:
            print_status("❌", f"{package} - Missing")
            print(f"   Install with: pip install {package}")

def check_environment_variables():
    print_header("Environment Variables Check")
    
    # Check for common cloud environment variables
    env_vars = [
        "PROJECT_ID",
        "GOOGLE_APPLICATION_CREDENTIALS", 
        "REGION",
        "ENDPOINT_ID",
        "BUCKET_NAME"
    ]
    
    for var in env_vars:
        value = os.getenv(var)
        if value:
            print_status("✅", f"{var} = {value}")
        else:
            print_status("⚠️", f"{var} - Not set (optional for local testing)")

def check_gcp_cli_tools():
    print_header("Google Cloud CLI Tools Check")
    
    tools = {
        "gcloud": "Google Cloud CLI",
        "bq": "BigQuery CLI", 
        "gsutil": "Cloud Storage CLI"
    }
    
    for tool, description in tools.items():
        try:
            result = subprocess.run([tool, "--version"], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                version = result.stdout.split('\n')[0]
                print_status("✅", f"{description} - {version}")
            else:
                print_status("❌", f"{description} - Not working")
        except (subprocess.TimeoutExpired, FileNotFoundError):
            print_status("❌", f"{description} - Not installed")

def check_gcp_authentication():
    print_header("Google Cloud Authentication Check")
    
    try:
        # Check if gcloud is authenticated
        result = subprocess.run(["gcloud", "auth", "list"], 
                              capture_output=True, text=True, timeout=10)
        if "ACTIVE" in result.stdout:
            print_status("✅", "Google Cloud authentication active")
            
            # Get current project
            project_result = subprocess.run(["gcloud", "config", "get-value", "project"], 
                                          capture_output=True, text=True, timeout=10)
            if project_result.stdout.strip():
                print_status("✅", f"Current GCP project: {project_result.stdout.strip()}")
            else:
                print_status("⚠️", "No default GCP project set")
        else:
            print_status("❌", "Google Cloud not authenticated")
            print("   Run: gcloud auth login")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        print_status("❌", "gcloud CLI not available")

def check_project_structure():
    print_header("Project Structure Check")
    
    base_path = Path(__file__).parent
    
    required_files = [
        "frontend/streamlit_app.py",
        "frontend/Dockerfile", 
        "frontend/requirements.txt",
        "etl_pipeline/credit_risk_etl.py",
        "ml_pipeline/vertex_ai_pipeline.py",
        "infrastructure/main.tf",
        "deploy.sh"
    ]
    
    for file_path in required_files:
        full_path = base_path / file_path
        if full_path.exists():
            print_status("✅", f"{file_path} - Exists")
        else:
            print_status("❌", f"{file_path} - Missing")

def check_model_artifacts():
    print_header("Model Artifacts Check")
    
    # Check for model files
    model_paths = [
        "../app/artifacts/model_data.joblib",
        "../artifacts/model_data.joblib"
    ]
    
    for path in model_paths:
        full_path = Path(__file__).parent / path
        if full_path.exists():
            print_status("✅", f"Model file found: {path}")
            
            # Try to load the model
            try:
                import joblib
                model_data = joblib.load(full_path)
                print_status("✅", f"Model loadable - Keys: {list(model_data.keys())}")
            except Exception as e:
                print_status("❌", f"Model load error: {e}")
        else:
            print_status("⚠️", f"Model file not found: {path}")

def test_local_streamlit():
    print_header("Local Streamlit Test")
    
    try:
        # Test if we can import the streamlit app
        sys.path.append(str(Path(__file__).parent / "frontend"))
        
        import streamlit_app
        print_status("✅", "Cloud-native Streamlit app imports successfully")
        
        # Check if the app class can be instantiated
        app = streamlit_app.CreditRiskApp()
        print_status("✅", "CreditRiskApp class instantiated")
        
    except Exception as e:
        print_status("❌", f"Streamlit app error: {e}")

def test_fallback_prediction():
    print_header("Fallback Prediction Test")
    
    try:
        sys.path.append(str(Path(__file__).parent / "frontend"))
        from streamlit_app import CreditRiskApp
        
        app = CreditRiskApp()
        
        # Test sample prediction
        test_features = {
            'age': 35,
            'income': 1500000,
            'loan_amount': 2000000,
            'loan_tenure_months': 60,
            'loan_to_income': 1.33,
            'number_of_dependants': 2,
            'avg_dpd_per_delinquency': 10,
            'delinquency_ratio': 15,
            'credit_utilization_ratio': 30,
            'number_of_open_accounts': 3,
            'residence_type': 'Owned',
            'loan_purpose': 'Personal',
            'loan_type': 'Secured',
            'employment_status': 'Salaried',
            'city_tier': 'Tier-1',
            'marital_status': 'Married'
        }
        
        result = app._local_prediction(test_features)
        print_status("✅", f"Local prediction working - Risk: {result['default_probability']:.2%}")
        
    except Exception as e:
        print_status("❌", f"Prediction test failed: {e}")

def generate_summary_report():
    print_header("Summary & Recommendations")
    
    print("📋 SETUP STATUS:")
    print("• Dependencies: Check individual package status above")
    print("• Environment: Most variables optional for local testing")
    print("• GCP Tools: Only needed for cloud deployment")
    print("• Authentication: Only needed for cloud deployment")
    
    print("\n🚀 NEXT STEPS:")
    print("1. ✅ Basic app: Run local version at http://localhost:8501")
    print("2. 📦 Missing packages: Install any missing dependencies")  
    print("3. ☁️ Cloud deployment: Set up GCP if you want cloud features")
    print("4. 🔑 Authentication: Run 'gcloud auth login' for cloud access")
    
    print("\n💡 RECOMMENDATIONS:")
    print("• For learning: Use local version - it's fully functional!")
    print("• For cloud: Set up GCP project and credentials")
    print("• For production: Follow cloud deployment guide")

def main():
    print("""
🏦 Cloud-Native Credit Risk Platform - Setup Diagnostic
========================================================
This tool checks if your cloud-native setup is working correctly.
""")
    
    check_python_dependencies()
    check_environment_variables() 
    check_gcp_cli_tools()
    check_gcp_authentication()
    check_project_structure()
    check_model_artifacts()
    test_local_streamlit()
    test_fallback_prediction()
    generate_summary_report()
    
    print(f"\n{'='*60}")
    print("🎉 Diagnostic Complete!")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
