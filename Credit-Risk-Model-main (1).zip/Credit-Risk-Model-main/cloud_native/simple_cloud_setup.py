#!/usr/bin/env python3
"""
Simplified Cloud Setup Script
Sets up basic Google Cloud resources for the credit risk platform
"""

import subprocess
import sys
import os
import json
from pathlib import Path

def run_command(command, description=""):
    """Run a shell command and return the result"""
    print(f"🔄 {description}")
    print(f"Running: {command}")
    
    try:
        result = subprocess.run(command.split(), capture_output=True, text=True, timeout=300)
        if result.returncode == 0:
            print(f"✅ Success: {description}")
            if result.stdout.strip():
                print(f"Output: {result.stdout.strip()}")
            return True, result.stdout
        else:
            print(f"❌ Failed: {description}")
            print(f"Error: {result.stderr}")
            return False, result.stderr
    except subprocess.TimeoutExpired:
        print(f"⏰ Timeout: {description}")
        return False, "Command timed out"
    except Exception as e:
        print(f"💥 Exception: {e}")
        return False, str(e)

def check_billing():
    """Check if billing is enabled"""
    print("\n" + "="*60)
    print("💳 Checking Billing Status")
    print("="*60)
    
    success, output = run_command("gcloud alpha billing projects describe credit-risk-platform-469416", 
                                  "Checking billing status")
    
    if success and "billingAccountName" in output:
        print("✅ Billing is enabled!")
        return True
    else:
        print("❌ Billing is not enabled.")
        print("\n🔗 Please enable billing:")
        print("1. Go to: https://console.cloud.google.com/billing")
        print("2. Create or link a billing account")
        print("3. Link it to project: credit-risk-platform-469416")
        print("4. Come back and run this script again")
        return False

def enable_apis():
    """Enable required Google Cloud APIs"""
    print("\n" + "="*60)
    print("🔧 Enabling Google Cloud APIs")
    print("="*60)
    
    apis = [
        "aiplatform.googleapis.com",
        "bigquery.googleapis.com", 
        "storage.googleapis.com",
        "run.googleapis.com",
        "cloudbuild.googleapis.com"
    ]
    
    for api in apis:
        success, _ = run_command(f"gcloud services enable {api}", f"Enabling {api}")
        if not success:
            return False
    
    return True

def create_storage_bucket():
    """Create a storage bucket for ML artifacts"""
    print("\n" + "="*60)
    print("🪣 Creating Storage Bucket")
    print("="*60)
    
    bucket_name = "credit-risk-platform-469416-ml-artifacts"
    
    success, _ = run_command(f"gsutil mb -p credit-risk-platform-469416 gs://{bucket_name}", 
                           f"Creating bucket {bucket_name}")
    
    if success:
        print(f"✅ Bucket created: gs://{bucket_name}")
        return bucket_name
    else:
        print("⚠️ Bucket might already exist, continuing...")
        return bucket_name

def create_bigquery_dataset():
    """Create BigQuery dataset"""
    print("\n" + "="*60)
    print("📊 Creating BigQuery Dataset")
    print("="*60)
    
    success, _ = run_command("bq mk --dataset credit-risk-platform-469416:credit_risk", 
                           "Creating BigQuery dataset")
    
    if success:
        print("✅ BigQuery dataset created: credit_risk")
        return True
    else:
        print("⚠️ Dataset might already exist, continuing...")
        return True

def upload_sample_data():
    """Upload sample data to BigQuery"""
    print("\n" + "="*60)
    print("📁 Uploading Sample Data")
    print("="*60)
    
    # For now, just create empty tables - real data upload would need proper schema
    tables = ["customers", "loans", "bureau_data", "predictions"]
    
    for table in tables:
        # Create a simple table structure
        schema_cmd = f"bq mk --table credit-risk-platform-469416:credit_risk.{table} id:STRING,created_at:TIMESTAMP"
        success, _ = run_command(schema_cmd, f"Creating table {table}")
    
    print("✅ Sample tables created in BigQuery")
    return True

def update_secrets_file():
    """Update the secrets file with the actual configuration"""
    print("\n" + "="*60)
    print("🔐 Updating Secrets Configuration")
    print("="*60)
    
    secrets_path = Path(__file__).parent / "frontend" / ".streamlit" / "secrets.toml"
    
    secrets_content = """# Streamlit Secrets Configuration
# Updated with actual GCP project details

[default]
PROJECT_ID = "credit-risk-platform-469416"
REGION = "us-central1"
ENDPOINT_ID = ""
BUCKET_NAME = "credit-risk-platform-469416-ml-artifacts"

# Note: ENDPOINT_ID will be populated after ML model deployment
"""
    
    with open(secrets_path, 'w') as f:
        f.write(secrets_content)
    
    print(f"✅ Updated secrets file: {secrets_path}")
    return True

def test_cloud_connection():
    """Test if cloud services are accessible"""
    print("\n" + "="*60)
    print("🧪 Testing Cloud Connection")
    print("="*60)
    
    # Test BigQuery
    success, _ = run_command("bq ls credit-risk-platform-469416:credit_risk", 
                           "Testing BigQuery access")
    
    # Test Storage
    success2, _ = run_command("gsutil ls gs://credit-risk-platform-469416-ml-artifacts", 
                            "Testing Storage access")
    
    if success and success2:
        print("✅ Cloud services are accessible!")
        return True
    else:
        print("⚠️ Some services might not be fully ready yet")
        return True

def main():
    """Main setup function"""
    print("""
🏦 Cloud-Native Credit Risk Platform - Simplified Setup
=======================================================
This script sets up basic Google Cloud resources.
""")
    
    # Check if we're authenticated
    success, _ = run_command("gcloud auth list", "Checking authentication")
    if not success:
        print("❌ Please run 'gcloud auth login' first")
        return
    
    # Check billing
    if not check_billing():
        return
    
    # Enable APIs
    if not enable_apis():
        print("❌ Failed to enable APIs")
        return
    
    # Create resources
    create_storage_bucket()
    create_bigquery_dataset()
    upload_sample_data()
    update_secrets_file()
    test_cloud_connection()
    
    print("\n" + "="*60)
    print("🎉 Basic Cloud Setup Complete!")
    print("="*60)
    print("\n✅ What's Ready:")
    print("• Google Cloud APIs enabled")
    print("• Storage bucket created")
    print("• BigQuery dataset created")
    print("• Secrets file updated")
    print("\n🚀 Next Steps:")
    print("1. Your Streamlit app can now access cloud resources")
    print("2. For ML model deployment, you'd need Vertex AI setup")
    print("3. For full production, you'd need Docker + Cloud Run")
    print("\n🌐 Test your cloud-enabled app:")
    print("streamlit run frontend/streamlit_app.py")

if __name__ == "__main__":
    main()
