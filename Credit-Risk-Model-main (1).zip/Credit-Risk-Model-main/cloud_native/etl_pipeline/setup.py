"""
Setup file for Credit Risk ETL Pipeline
"""

from setuptools import setup, find_packages

setup(
    name='credit-risk-etl',
    version='1.0.0',
    description='Credit Risk ETL Pipeline for Google Cloud Dataflow',
    packages=find_packages(),
    install_requires=[
        'apache-beam[gcp]==2.53.0',
        'google-cloud-bigquery==3.13.0',
        'google-cloud-storage==2.10.0',
        'pandas==2.1.3',
        'numpy==1.24.3'
    ],
    python_requires='>=3.8',
)
