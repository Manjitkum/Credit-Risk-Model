"""
Credit Risk ETL Pipeline using Apache Beam for Google Cloud Dataflow
Processes and transforms credit risk data for ML model training
"""

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.io import ReadFromBigQuery, WriteToBigQuery
import json
import logging
from typing import Dict, Any


class DataTransformDoFn(beam.DoFn):
    """Custom DoFn for data transformation and feature engineering"""
    
    def process(self, element: Dict[str, Any]):
        """Transform and engineer features for credit risk modeling"""
        try:
            # Basic data cleaning and validation
            if not self._validate_record(element):
                return
            
            # Feature engineering
            transformed = self._engineer_features(element)
            
            # Data quality checks
            if self._quality_check(transformed):
                yield transformed
                
        except Exception as e:
            logging.error(f"Error processing record: {e}")
            # Could add to dead letter queue here
    
    def _validate_record(self, record: Dict[str, Any]) -> bool:
        """Validate essential fields are present and valid"""
        required_fields = ['cust_id', 'age', 'income', 'loan_amount']
        
        for field in required_fields:
            if field not in record or record[field] is None:
                return False
        
        # Validate ranges
        if record['age'] < 18 or record['age'] > 100:
            return False
        if record['income'] <= 0:
            return False
        if record['loan_amount'] <= 0:
            return False
            
        return True
    
    def _engineer_features(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """Engineer features for credit risk modeling"""
        
        # Calculate loan to income ratio
        record['loan_to_income'] = record['loan_amount'] / record['income']
        
        # Calculate credit utilization if available
        if 'credit_limit' in record and record['credit_limit'] > 0:
            record['credit_utilization_ratio'] = (
                record.get('credit_used', 0) / record['credit_limit'] * 100
            )
        
        # Age groups
        if record['age'] < 25:
            record['age_group'] = 'young'
        elif record['age'] < 45:
            record['age_group'] = 'middle'
        else:
            record['age_group'] = 'senior'
        
        # Income groups (in millions)
        income_millions = record['income'] / 1000000
        if income_millions < 1:
            record['income_group'] = 'low'
        elif income_millions < 3:
            record['income_group'] = 'medium'
        else:
            record['income_group'] = 'high'
        
        # Risk indicators
        record['high_loan_to_income'] = 1 if record['loan_to_income'] > 5 else 0
        
        return record
    
    def _quality_check(self, record: Dict[str, Any]) -> bool:
        """Final quality checks before output"""
        # Check for extreme outliers
        if record['loan_to_income'] > 20:  # Unrealistic ratio
            return False
        if record['age'] > 95:  # Edge case
            return False
        
        return True


class AggregateMetricsDoFn(beam.DoFn):
    """Calculate aggregated metrics for monitoring"""
    
    def process(self, element):
        # Calculate various metrics for data quality monitoring
        metrics = {
            'total_records': 1,
            'avg_age': element['age'],
            'avg_income': element['income'],
            'avg_loan_amount': element['loan_amount'],
            'high_risk_indicators': element.get('high_loan_to_income', 0)
        }
        yield metrics


def run_pipeline(project_id: str, region: str, temp_location: str):
    """Main pipeline execution function"""
    
    # Pipeline options
    pipeline_options = PipelineOptions([
        '--project', project_id,
        '--region', region,
        '--runner', 'DataflowRunner',
        '--temp_location', temp_location,
        '--setup_file', './setup.py'
    ])
    
    with beam.Pipeline(options=pipeline_options) as pipeline:
        
        # Read from BigQuery tables
        customers_query = f"""
            SELECT * FROM `{project_id}.credit_risk.customers`
        """
        
        loans_query = f"""
            SELECT * FROM `{project_id}.credit_risk.loans`
        """
        
        bureau_query = f"""
            SELECT * FROM `{project_id}.credit_risk.bureau_data`
        """
        
        # Read data
        customers = (pipeline
                    | 'Read Customers' >> ReadFromBigQuery(query=customers_query))
        
        loans = (pipeline
                | 'Read Loans' >> ReadFromBigQuery(query=loans_query))
        
        bureau = (pipeline
                 | 'Read Bureau' >> ReadFromBigQuery(query=bureau_query))
        
        # Join datasets using a simpler approach
        def join_records(cust_id_and_records):
            cust_id, records = cust_id_and_records
            customers_data = list(records['customers'])
            loans_data = list(records['loans'])  
            bureau_data = list(records['bureau'])
            
            result = {}
            if customers_data:
                result.update(customers_data[0])
            if loans_data:
                result.update(loans_data[0])
            if bureau_data:
                result.update(bureau_data[0])
            
            return result
        
        keyed_customers = customers | 'Key Customers' >> beam.Map(lambda x: (x['cust_id'], x))
        keyed_loans = loans | 'Key Loans' >> beam.Map(lambda x: (x['cust_id'], x))
        keyed_bureau = bureau | 'Key Bureau' >> beam.Map(lambda x: (x['cust_id'], x))
        
        joined_data = ({
            'customers': keyed_customers,
            'loans': keyed_loans,
            'bureau': keyed_bureau
        }
        | 'Join Data' >> beam.CoGroupByKey()
        | 'Flatten Joined' >> beam.Map(join_records))
        
        # Transform data
        transformed_data = (joined_data
                           | 'Transform Data' >> beam.ParDo(DataTransformDoFn()))
        
        # Write to processed table
        (transformed_data
         | 'Write to BigQuery' >> WriteToBigQuery(
             table=f'{project_id}:credit_risk.processed_data',
             schema='SCHEMA_AUTODETECT',
             write_disposition=beam.io.BigQueryDisposition.WRITE_TRUNCATE
         ))
        
        # Calculate and store metrics
        metrics = (transformed_data
                  | 'Calculate Metrics' >> beam.ParDo(AggregateMetricsDoFn())
                  | 'Combine Metrics' >> beam.CombineGlobally(
                      beam.combiners.MeanCombineFn()
                  )
                  | 'Format Metrics' >> beam.Map(lambda x: {
                      'pipeline_run_time': beam.utils.timestamp.Timestamp.now(),
                      'metrics': x
                  }))
        
        (metrics
         | 'Write Metrics' >> WriteToBigQuery(
             table=f'{project_id}:credit_risk.pipeline_metrics',
             schema='SCHEMA_AUTODETECT',
             write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
         ))


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--project_id', required=True)
    parser.add_argument('--region', default='us-central1')
    parser.add_argument('--temp_location', required=True)
    
    args = parser.parse_args()
    
    run_pipeline(args.project_id, args.region, args.temp_location)
