"""
Credit Risk ML Pipeline using Vertex AI
Handles model training, evaluation, and deployment
"""

import os
import joblib
import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, Any, Tuple

from google.cloud import aiplatform
from google.cloud import bigquery
from google.cloud import storage
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import roc_auc_score, accuracy_score, classification_report
import matplotlib.pyplot as plt
import seaborn as sns


class CreditRiskMLPipeline:
    """Complete ML Pipeline for Credit Risk modeling on Vertex AI"""
    
    def __init__(self, project_id: str, region: str, bucket_name: str):
        self.project_id = project_id
        self.region = region
        self.bucket_name = bucket_name
        
        # Initialize clients
        aiplatform.init(project=project_id, location=region)
        self.bq_client = bigquery.Client(project=project_id)
        self.storage_client = storage.Client(project=project_id)
        
        self.model = None
        self.scaler = None
        self.label_encoders = {}
        self.feature_names = None
        
    def load_data_from_bigquery(self, table_name: str = "credit_risk.processed_data") -> pd.DataFrame:
        """Load processed data from BigQuery"""
        query = f"""
        SELECT * FROM `{self.project_id}.{table_name}`
        """
        
        df = self.bq_client.query(query).to_dataframe()
        print(f"Loaded {len(df)} records from BigQuery")
        return df
    
    def prepare_features(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray, list]:
        """Prepare features for model training"""
        
        # Define target variable
        target_col = 'default'
        
        # Features to exclude
        exclude_cols = ['cust_id', target_col, 'loan_id'] + \
                      [col for col in df.columns if col.endswith('_id')]
        
        # Select feature columns
        feature_cols = [col for col in df.columns if col not in exclude_cols]
        
        # Handle categorical variables
        categorical_cols = df[feature_cols].select_dtypes(include=['object']).columns
        
        df_processed = df[feature_cols].copy()
        
        # Encode categorical variables
        for col in categorical_cols:
            if col not in self.label_encoders:
                self.label_encoders[col] = LabelEncoder()
                df_processed[col] = self.label_encoders[col].fit_transform(df[col].fillna('Unknown'))
            else:
                df_processed[col] = self.label_encoders[col].transform(df[col].fillna('Unknown'))
        
        # Handle missing values
        df_processed = df_processed.fillna(df_processed.median())
        
        # Scale numerical features
        numerical_cols = df_processed.select_dtypes(include=[np.number]).columns
        
        if self.scaler is None:
            self.scaler = StandardScaler()
            df_processed[numerical_cols] = self.scaler.fit_transform(df_processed[numerical_cols])
        else:
            df_processed[numerical_cols] = self.scaler.transform(df_processed[numerical_cols])
        
        self.feature_names = df_processed.columns.tolist()
        
        X = df_processed.values
        y = df[target_col].values
        
        return X, y, self.feature_names
    
    def train_model(self, X: np.ndarray, y: np.ndarray) -> Dict[str, float]:
        """Train XGBoost model with hyperparameter optimization"""
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # XGBoost parameters optimized for credit risk
        params = {
            'objective': 'binary:logistic',
            'eval_metric': 'auc',
            'max_depth': 6,
            'learning_rate': 0.1,
            'n_estimators': 200,
            'subsample': 0.8,
            'colsample_bytree': 0.8,
            'random_state': 42,
            'scale_pos_weight': len(y_train[y_train == 0]) / len(y_train[y_train == 1])  # Handle class imbalance
        }
        
        # Train model
        self.model = xgb.XGBClassifier(**params)
        self.model.fit(X_train, y_train)
        
        # Predictions
        y_pred = self.model.predict(X_test)
        y_pred_proba = self.model.predict_proba(X_test)[:, 1]
        
        # Calculate metrics
        auc_score = roc_auc_score(y_test, y_pred_proba)
        gini_score = 2 * auc_score - 1
        accuracy = accuracy_score(y_test, y_pred)
        
        metrics = {
            'auc': auc_score,
            'gini': gini_score,
            'accuracy': accuracy
        }
        
        print(f"Model Performance:")
        print(f"AUC: {auc_score:.3f}")
        print(f"Gini: {gini_score:.3f}")
        print(f"Accuracy: {accuracy:.3f}")
        
        # Feature importance analysis
        self._analyze_feature_importance()
        
        return metrics
    
    def _analyze_feature_importance(self):
        """Analyze and save feature importance"""
        if self.model is None:
            return
        
        importance_df = pd.DataFrame({
            'feature': self.feature_names,
            'importance': self.model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        print("\nTop 10 Most Important Features:")
        print(importance_df.head(10))
        
        # Save feature importance plot
        plt.figure(figsize=(10, 8))
        sns.barplot(data=importance_df.head(15), x='importance', y='feature')
        plt.title('Top 15 Feature Importance - Credit Risk Model')
        plt.tight_layout()
        plt.savefig('/tmp/feature_importance.png', dpi=300, bbox_inches='tight')
        
        # Upload to Cloud Storage
        self._upload_to_gcs('/tmp/feature_importance.png', 'feature_importance.png')
        
        return importance_df
    
    def save_model_artifacts(self) -> str:
        """Save model artifacts to Cloud Storage"""
        
        # Create model artifacts
        artifacts = {
            'model': self.model,
            'scaler': self.scaler,
            'label_encoders': self.label_encoders,
            'feature_names': self.feature_names
        }
        
        # Save locally first
        model_path = '/tmp/credit_risk_model.joblib'
        joblib.dump(artifacts, model_path)
        
        # Upload to Cloud Storage
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        gcs_path = f'models/credit_risk_model_{timestamp}.joblib'
        
        self._upload_to_gcs(model_path, gcs_path)
        
        print(f"Model artifacts saved to gs://{self.bucket_name}/{gcs_path}")
        return gcs_path
    
    def _upload_to_gcs(self, local_path: str, gcs_path: str):
        """Upload file to Google Cloud Storage"""
        bucket = self.storage_client.bucket(self.bucket_name)
        blob = bucket.blob(gcs_path)
        blob.upload_from_filename(local_path)
    
    def deploy_to_vertex_ai(self, model_gcs_path: str, endpoint_name: str = None) -> str:
        """Deploy model to Vertex AI endpoint"""
        
        if endpoint_name is None:
            endpoint_name = f"credit-risk-endpoint-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        
        # Create custom prediction container
        container_spec = {
            "image_uri": "gcr.io/cloud-aiplatform/prediction/xgboost-cpu.1-7:latest",
            "predict_route": "/predict",
            "health_route": "/health"
        }
        
        # Upload model to Vertex AI Model Registry
        model = aiplatform.Model.upload(
            display_name=f"credit-risk-model-{datetime.now().strftime('%Y%m%d-%H%M%S')}",
            artifact_uri=f"gs://{self.bucket_name}/{model_gcs_path}",
            serving_container_image_uri=container_spec["image_uri"],
            serving_container_predict_route=container_spec["predict_route"],
            serving_container_health_route=container_spec["health_route"]
        )
        
        # Create endpoint
        endpoint = aiplatform.Endpoint.create(display_name=endpoint_name)
        
        # Deploy model to endpoint
        model.deploy(
            endpoint=endpoint,
            deployed_model_display_name="credit-risk-v1",
            traffic_percentage=100,
            machine_type="n1-standard-2",
            min_replica_count=1,
            max_replica_count=3
        )
        
        print(f"Model deployed to endpoint: {endpoint.resource_name}")
        return endpoint.resource_name
    
    def run_full_pipeline(self) -> Dict[str, Any]:
        """Run the complete ML pipeline"""
        
        print("Starting Credit Risk ML Pipeline...")
        
        # 1. Load data
        df = self.load_data_from_bigquery()
        
        # 2. Prepare features
        X, y, feature_names = self.prepare_features(df)
        
        # 3. Train model
        metrics = self.train_model(X, y)
        
        # 4. Save model artifacts
        model_gcs_path = self.save_model_artifacts()
        
        # 5. Deploy to Vertex AI
        endpoint_name = self.deploy_to_vertex_ai(model_gcs_path)
        
        pipeline_results = {
            'metrics': metrics,
            'model_path': model_gcs_path,
            'endpoint': endpoint_name,
            'feature_count': len(feature_names),
            'training_samples': len(X)
        }
        
        print("Pipeline completed successfully!")
        return pipeline_results


def main():
    """Main function to run the pipeline"""
    
    # Configuration
    PROJECT_ID = os.getenv('PROJECT_ID', 'your-project-id')
    REGION = os.getenv('REGION', 'us-central1')
    BUCKET_NAME = os.getenv('BUCKET_NAME', 'your-bucket-name')
    
    # Initialize and run pipeline
    pipeline = CreditRiskMLPipeline(PROJECT_ID, REGION, BUCKET_NAME)
    results = pipeline.run_full_pipeline()
    
    print(f"Pipeline Results: {results}")


if __name__ == '__main__':
    main()
