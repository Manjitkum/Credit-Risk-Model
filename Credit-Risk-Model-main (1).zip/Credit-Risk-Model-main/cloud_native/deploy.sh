#!/bin/bash

# Cloud-Native Credit Risk Platform Deployment Script
# This script deploys the entire platform to Google Cloud Platform

set -e

# Configuration
PROJECT_ID=${1:-"your-project-id"}
REGION=${2:-"us-central1"}
ENVIRONMENT=${3:-"prod"}

echo "🚀 Deploying Cloud-Native Credit Risk Platform"
echo "Project: $PROJECT_ID"
echo "Region: $REGION"
echo "Environment: $ENVIRONMENT"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    print_status "Checking prerequisites..."
    
    # Check if gcloud is installed
    if ! command -v gcloud &> /dev/null; then
        print_error "gcloud CLI is not installed. Please install it first."
        exit 1
    fi
    
    # Check if terraform is installed
    if ! command -v terraform &> /dev/null; then
        print_error "Terraform is not installed. Please install it first."
        exit 1
    fi
    
    # Check if docker is installed
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed. Please install it first."
        exit 1
    fi
    
    print_success "All prerequisites met!"
}

# Set up GCP project
setup_gcp_project() {
    print_status "Setting up GCP project..."
    
    # Set project
    gcloud config set project $PROJECT_ID
    
    # Enable billing (check if needed)
    print_warning "Please ensure billing is enabled for project $PROJECT_ID"
    
    print_success "GCP project setup complete!"
}

# Deploy infrastructure with Terraform
deploy_infrastructure() {
    print_status "Deploying infrastructure with Terraform..."
    
    cd infrastructure
    
    # Initialize Terraform
    terraform init
    
    # Plan deployment
    terraform plan -var="project_id=$PROJECT_ID" -var="region=$REGION" -var="environment=$ENVIRONMENT"
    
    # Apply infrastructure
    terraform apply -var="project_id=$PROJECT_ID" -var="region=$REGION" -var="environment=$ENVIRONMENT" -auto-approve
    
    cd ..
    
    print_success "Infrastructure deployed!"
}

# Upload data to BigQuery
upload_data() {
    print_status "Uploading data to BigQuery..."
    
    # Upload customers data
    bq load --source_format=CSV --skip_leading_rows=1 \
        $PROJECT_ID:credit_risk.customers \
        ../dataset/customers.csv \
        cust_id:STRING,age:INTEGER,gender:STRING,marital_status:STRING,employment_status:STRING,income:FLOAT,number_of_dependants:INTEGER,residence_type:STRING,years_at_current_address:INTEGER,city:STRING,state:STRING,zipcode:STRING
    
    # Upload loans data
    bq load --source_format=CSV --skip_leading_rows=1 \
        $PROJECT_ID:credit_risk.loans \
        ../dataset/loans.csv \
        cust_id:STRING,loan_id:STRING,loan_amount:FLOAT,loan_tenure_months:INTEGER,loan_purpose:STRING,loan_type:STRING,default:INTEGER
    
    # Upload bureau data
    bq load --source_format=CSV --skip_leading_rows=1 \
        $PROJECT_ID:credit_risk.bureau_data \
        ../dataset/bureau_data.csv \
        cust_id:STRING,number_of_open_accounts:INTEGER,credit_utilization_ratio:FLOAT,delinquency_ratio:FLOAT,avg_dpd_per_delinquency:FLOAT
    
    print_success "Data uploaded to BigQuery!"
}

# Run ETL pipeline
run_etl_pipeline() {
    print_status "Running ETL pipeline with Cloud Dataflow..."
    
    cd etl_pipeline
    
    # Create temp bucket if it doesn't exist
    gsutil mb -p $PROJECT_ID gs://$PROJECT_ID-dataflow-temp || true
    
    # Run the pipeline
    python credit_risk_etl.py \
        --project_id=$PROJECT_ID \
        --region=$REGION \
        --temp_location=gs://$PROJECT_ID-dataflow-temp
    
    cd ..
    
    print_success "ETL pipeline completed!"
}

# Train and deploy ML model
deploy_ml_model() {
    print_status "Training and deploying ML model with Vertex AI..."
    
    cd ml_pipeline
    
    # Set environment variables
    export PROJECT_ID=$PROJECT_ID
    export REGION=$REGION
    export BUCKET_NAME=$PROJECT_ID-ml-artifacts
    
    # Run ML pipeline
    python vertex_ai_pipeline.py
    
    cd ..
    
    print_success "ML model deployed!"
}

# Build and deploy frontend
deploy_frontend() {
    print_status "Building and deploying frontend application..."
    
    cd frontend
    
    # Build Docker image
    docker build -t gcr.io/$PROJECT_ID/credit-risk-app:latest .
    
    # Push to Container Registry
    docker push gcr.io/$PROJECT_ID/credit-risk-app:latest
    
    # Deploy to Cloud Run (Terraform already created the service)
    gcloud run deploy credit-risk-app \
        --image gcr.io/$PROJECT_ID/credit-risk-app:latest \
        --platform managed \
        --region $REGION \
        --allow-unauthenticated \
        --set-env-vars PROJECT_ID=$PROJECT_ID,REGION=$REGION
    
    cd ..
    
    print_success "Frontend deployed!"
}

# Setup monitoring
setup_monitoring() {
    print_status "Setting up monitoring and alerting..."
    
    # Create alerting policies (simplified version)
    gcloud alpha monitoring policies create --policy-from-file=monitoring/alert-policy.yaml || true
    
    print_success "Monitoring setup complete!"
}

# Get deployment information
get_deployment_info() {
    print_status "Getting deployment information..."
    
    cd infrastructure
    
    APP_URL=$(terraform output -raw app_url)
    DATASET=$(terraform output -raw bigquery_dataset)
    BUCKET=$(terraform output -raw storage_bucket)
    
    cd ..
    
    echo ""
    echo "🎉 Deployment Complete!"
    echo "================================="
    echo "📱 Application URL: $APP_URL"
    echo "📊 BigQuery Dataset: $PROJECT_ID:$DATASET"
    echo "🪣 Storage Bucket: $BUCKET"
    echo "🔧 Region: $REGION"
    echo "================================="
    echo ""
    echo "🔗 Additional Resources:"
    echo "• Cloud Console: https://console.cloud.google.com/home/dashboard?project=$PROJECT_ID"
    echo "• Vertex AI: https://console.cloud.google.com/vertex-ai?project=$PROJECT_ID"
    echo "• BigQuery: https://console.cloud.google.com/bigquery?project=$PROJECT_ID"
    echo "• Cloud Run: https://console.cloud.google.com/run?project=$PROJECT_ID"
    echo ""
}

# Main deployment function
main() {
    echo "🏦 Cloud-Native Credit Risk Platform Deployment"
    echo "=============================================="
    
    check_prerequisites
    setup_gcp_project
    deploy_infrastructure
    upload_data
    run_etl_pipeline
    deploy_ml_model
    deploy_frontend
    setup_monitoring
    get_deployment_info
    
    print_success "🚀 All components deployed successfully!"
}

# Run main function
main
